<?php
if (!isset($_SESSION)) {
    session_start();
  }
$scriptName = basename(__FILE__);
require_once("conn.php");
if(!empty($_SESSION["uid"])){
	header("location: ./");
	exit;
}

$Option = !empty($_GET["Option"])? $_GET["Option"] : "";
$Option = !empty($_POST["Option"])? $_POST["Option"] : $Option;

$mess = "";

if($Option == "Register"){
	$uName = $_POST["uName"];
	$uEmail = $_POST["uEmail"];
	$uPass = $_POST["uPass"];
	//$strSQL = "SELECT uid FROM tbUsers WHERE uEmail = '".mysqli_real_escape_string($conn, stripslashes($uEmail))."'";
	//echo "strSQL=$strSQL<br />\n";
	/*$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){
		$mess = '
		<div class="alert alert-danger mt-3">
			<strong>Note!</strong> That email is already in use!
		</div>';*/
	 $strSQL = "SELECT uid FROM tbUsers WHERE uEmail = ?;";
	 if($stmt = mysqli_prepare($conn, $strSQL)){
		mysqli_stmt_bind_param($stmt, "s", $param_uEmail);
		$param_uEmail = $uEmail;
		if(mysqli_stmt_execute($stmt)){
			mysqli_stmt_store_result($stmt);
			if(mysqli_stmt_num_rows($stmt) >= 1){
				$mess = '
				<div class="alert alert-danger mt-3">
					<strong>Note!</strong> That email is already in use!
				</div>';
			}else{
				$strSQL = "INSERT INTO tbUsers SET uRole = 0, uName = '".mysqli_real_escape_string($conn, stripslashes($uName))."', uEmail = '".mysqli_real_escape_string($conn, stripslashes($uEmail))."', uPass = '".md5($uPass)."', uCreated = NOW()";
				//echo "strSQL=$strSQL<br />\n";
				$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
				header("location:login.php");
				exit;
			}
		}else{
			 $mess = '
				<div class="alert alert-danger mt-3">
					<strong>Note!</strong> Execute error!
				</div>';
		}
		mysqli_stmt_close($stmt);
	}else{
		 $mess = '
			<div class="alert alert-danger mt-3">
				<strong>Note!</strong> Prepare error!
			</div>';
	}
}
$pageTitle ="Cinema | Register";
include_once("header.php");
?>
<section class="bgColorWhite py-5">
	<div class="container">
		<h1 class="colorBlue text-center py-4 styleFont">Register</h1>
		<div class="row">
			<div class="col-sm-6 py-4 mx-auto bgColorBlack">
				<form action="" method="post" name="registerForm" id="registerForm">
					<input type="hidden" name="Option" id="Option" value="Register"/>
					<div class="form-group colorWhite">
						<label for="uName">Username:</label>
						<input type="text" class="form-control" placeholder="Username" name="uName" id="uName" required/>
					</div>
					<div class="form-group colorWhite">
						<label for="uEmail">Email:</label>
						<input type="email" class="form-control" placeholder="Email" name="uEmail" id="uEmail" required/>
					</div>
					<div class="form-group colorWhite">
						<label for="pass">Password:</label>
						<input type="password" class="form-control" placeholder="Password" id="uPass" minlength="5" name="uPass" required/>
					</div>
					<div class="form-group colorWhite">
						<label for="pass">Repeat password:</label>
						<input type="password" class="form-control" placeholder="Repeat password" id="uRepeatPass" minlength="5" name="uRepeatPass" required/>
					</div>
					<h6 class="colorBlue text-right">Required fields*</h6>
					<button type="submit" class="btn btnColor">Submit</button>
					<h6 class="colorWhite align-itself-right mt-3">Already have an account? <a class="colorBlue" href="login.php">Login</a></h6>
				</form>
			</div>
		</div>
		<?php $mess?>
	</div>
</section>
<script>
$(function(){
	$("#registerForm").validate({
		rules:{
			uName: "required",
			uPass: {
				required:	true,
				minlength:	5
			},
			uRepeatPass: {
				required:	true,
				minlength:	5,
				equalTo:	"#uPass"
			},
			uEmail: {
				required:	true,
				email:		true
			}
		},
		messages: {
			uName:			"Please enter a username",
			uPass:{
				required:	"Please enter a password.",
				minlength:	"Password must be at least 5 characters long."
			},
			uRepeatPass: {
				required:	"Please enter a password.",
				minlength:	"Password must be at least 5 characters long.",
				equalTo:	"Password and repeat password do not match."
			},
			uEmail:{
				required:	"Please enter your email adress.",
				email:		"Please enter a valid email adress."
			}
		},
		submitHandler: function(form) {
		form.submit();
		}
	});
});
</script>
<?php
include_once("footer.php");
?>