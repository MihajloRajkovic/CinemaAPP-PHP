<?php
if (!isset($_SESSION)) {
    session_start();
  }
$scriptName = basename(__FILE__);
require_once "conn.php";

$scrid	= !empty($_SESSION["scrid"]) ? (int)$_SESSION["scrid"] : 0;
$scrid	= !empty($_GET["scrid"]) ? (int)$_GET["scrid"] : $scrid;
$scrid	= !empty($_POST["scrid"]) ? (int)$_POST["scrid"] : $scrid;
$_SESSION["scrid"] = $scrid;

$Option	= !empty($_GET["Option"]) ? $_GET["Option"] : "";
$Option	= !empty($_POST["Option"]) ? $_POST["Option"] : $Option;

if(empty($_SESSION["uid"])){
	header("location: login.php?BackURL=".$scriptName."&BackOption=".$Option);
	exit;
}
if(empty($_SESSION["scrid"])){
	header("location: ./");
	exit;
}

$mess	= "";
//echo "_SESSION<pre>";print_r($_SESSION);echo "</pre>";
//echo "_GET<pre>";print_r($_GET);echo "</pre>";
//echo "_POST<pre>";print_r($_POST);echo "</pre>";
if($Option == "Reserve"){
    $strSQL="SELECT oid FROM tbOrders WHERE uid = ".(int)$_SESSION["uid"]." AND scrid = ".(int)$_SESSION["scrid"];
	//echo "strSQL = $strSQL<br />\n";
	$rez = mysqli_query($conn,$strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if(mysqli_num_rows($rez)== 0){
		$strSQL = "INSERT INTO tbOrders SET uid = ".(int)$_SESSION["uid"].", scrid = ".(int)$_SESSION["scrid"].", oCreated = NOW()";
		//echo "strSQL = $strSQL<br />\n";
		mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
		$oid	= mysqli_insert_id($conn);
	}else{
		$row = mysqli_fetch_assoc($rez);
		$oid = $row["oid"];
	}

	$mess	= '
			<h5 class="colorBlack mb-3">Here is your QR code for the reservation:</h5>
			<img class="img-fluid" src="//chart.googleapis.com/chart?chs=150x150&amp;cht=qr&amp;chl='.$oid.'">
		    ';
}
$pageTitle = "Cinema | Reservation";
include_once("header.php");
?>
<!--section reservations-->
<section class="bgColorWhite py-5">
	<div class="container py-5">
		<div class="row text-center">
			<div class="col-md-6 mx-auto">
				<h1 class="colorBlue styleFont mt-5 mb-3">Reservations</h1>
				<?=$mess?>
			</div>
		</div>
   </div>
</section>
<!--end of section reservations-->
<?php
include_once("footer.php");
?>