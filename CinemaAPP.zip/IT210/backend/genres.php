<?php
if (!isset($_SESSION)) {
    session_start();
  }
require_once("../conn.php");

if(!empty($_SESSION["uid"]) AND ($_SESSION["uRole"] == 0)){
	header("location: ../");
	exit;
}

$Option	= !empty($_GET["Option"]) ? $_GET["Option"] : "";
$Option	= !empty($_POST["Option"]) ? $_POST["Option"] : $Option;
$gid	= !empty($_GET["gid"]) ? (int)$_GET["gid"] : 0;
$gid	= !empty($_POST["gid"]) ? (int)$_POST["gid"] : $gid;

$msg = '';
if($Option == "Deactivate"){
	$strSQL = "UPDATE tbGenres SET gActive = 0, gUpdated = NOW() WHERE gid = ".(int)$_GET["gid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-danger mt-5">
	  <strong>Warning!</strong> Item Deactivated.
	</div>';
}elseif($Option == "Activate"){
	$strSQL = "UPDATE tbGenres SET gActive = 1, gUpdated = NOW() WHERE gid = ".(int)$_GET["gid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-success mt-5">
	  <strong>Success!</strong> Item Activated.
	</div>';
}elseif($Option == "Insert"){
	$gName = $_POST["gName"];
	$strSQL = "SELECT gid FROM tbGenres WHERE gName = '".mysqli_real_escape_string($conn,stripslashes($gName))."'";
	//echo "strSQL = $strSQL<br />\n";
	$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){
		$msg = '
		<div class="alert alert-danger mt-3">
			<strong>Note!</strong> That genre already exists!
		</div>';
	}else{
		$strSQL = "INSERT INTO tbGenres SET gName = '".mysqli_real_escape_string($conn,stripslashes($gName))."',
		gCreated = NOW()";
		//echo "strSQL = $strSQL<br />\n";
		$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
		$msg = '
		<div class="alert alert-success mt-3">
			<strong>Sucess!</strong> Genre added.
		</div>';
	}
}
$pageTitle = "Cinema | Genres";
include_once("header.php");
?>
<form action="" method="post" id="frmGenres" name="frmGenres">
<div class="container py-5">
	<div class="row text-center">
		<div class="col-sm-10 mx-auto">
			<h1 class="colorBlue styleFont mt-5 mb-3">Genres records</h1>
			<?php if($Option == "AddNew"){?>
				<div class="row text-left">
					<div class="col-sm-6 py-4 bgColorBlack mx-auto">
						<input type="hidden" id="Option" name="Option" value="Insert" />
						<div class="form-group colorWhite">
							<label for="mrName">Genre name:</label>
							<input type="text" class="form-control" placeholder="Movie room name" name="mrName" id="mrName" required/>
						</div>
						<button type="submit" class="btn btnColor" id="addBtn">Add</button>
					</div>
				</div>
				<?php }else{?>
					
					<div class="table-responsive">
						<table class="table table-dark table-hover table-bordered text-center">
							<thead class="thead-dark">
								<tr>
									<th>Genre name</th>
									<th>Genre active status</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php
							$strSQL = "SELECT * FROM tbGenres";
							//echo "strSQL = $strSQL<br />\n";
							$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
							while($row = mysqli_fetch_assoc($rez)){
								?>
								<tr>
									<td><?=$row["gName"]?></td>
									<td><?=(!empty($row["gActive"]) ? "ACTIVE" : "INACTIVE")?></td>
									<td nowrap>
										<?php if(empty($row["gActive"])){?>
											<button class="btn btn-success btn-sm" onclick="if(confirm('Do you really want to Activate the selected item?')){location='?Option=Activate&gid=<?=$row["gid"]?>'}"><i class="fas fa-check-circle"></i></i>
										<?php }else{?>
											<button class="btn btn-danger btn-sm" onclick="if(confirm('Do you really want to Deactivate the selected item?')){location='?Option=Deactivate&gid=<?=$row["gid"]?>'}"><i class="fas fa-trash-alt "></i>
										<?php }?>
										</button>
									</td>
								</tr>
								<?php
							}
							?>
							</tbody>
						</table>
					</div>
				<?php
				}
				?>
		</div>
	</div>
	<?php $msg?>
</div>
</form>
<script>
$(function(){
	$("#frmGenres").validate({
		rules:{
			gName:"required"
		},
		messages:{
			gName:"Enter genre name"
		},
		submitHandler: function(form) {
			form.submit();
		}
	});
});
</script>
<?php
include_once("../footer.php");
?>