<?php
if (!isset($_SESSION)) {
    session_start();
  }
require_once("../conn.php");

if(!empty($_SESSION["uid"]) AND ($_SESSION["uRole"] == 0)){
	header("location: ../");
	exit;
}

$Option	= !empty($_GET["Option"]) ? $_GET["Option"] : "";
$Option	= !empty($_POST["Option"]) ? $_POST["Option"] : $Option;
$scrid	= !empty($_GET["scrid"]) ? (int)$_GET["scrid"] : 0;
$scrid	= !empty($_POST["scrid"]) ? (int)$_POST["scrid"] : $scrid;

$msg = '';
if($Option == "Deactivate"){
	$strSQL = "UPDATE tbScreenings SET scrActive = 0, scrUpdated = NOW() WHERE scrid = ".(int)$_GET["scrid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-danger mt-5">
	  <strong>Warning!</strong> Item Deactivated.
	</div>';
}elseif($Option == "Activate"){
	$strSQL = "UPDATE tbScreenings SET scrActive = 1, scrUpdated = NOW() WHERE scrid = ".(int)$_GET["scrid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-success mt-5">
	  <strong>Success!</strong> Item Activated.
	</div>';
}elseif($Option == "Insert"){
	$scrDate = $_POST["scrDate"];
	$scrHour = $_POST["scrHour"];
	$scrTime = $scrDate.' '.$scrHour;
	$strSQL = "SELECT scrid FROM tbScreenings WHERE scrTime = '".$scrTime."'";
	$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){
		$msg = '
		<div class="alert alert-danger mt-3">
			<strong>Note!</strong> That screening already exists!
		</div>';
	}else{
		$strSQL = "INSERT INTO tbScreenings SET mid = ".(int)$_POST["mid"].", mrid = ".(int)$_POST["mrid"].", scrTicketPrice = ".(float)$_POST["scrTicketPrice"].", scrTime = '".$scrTime.":00:00', scrCreated = NOW()";
		$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
		$msg = '
		<div class="alert alert-sucess mt-3">
			<strong>Sucess!</strong> Screening added.
		</div>';
	}
}elseif($Option == "Update"){
	$scrDate = $_POST["scrDate"];
	$scrHour = $_POST["scrHour"];
	$scrTime = $scrDate.' '.$scrHour;
	$strSQL = "UPDATE tbScreenings SET mrid = ".$_POST["mrid"].", scrTicketPrice = ".(float)$_POST["scrTicketPrice"].", 
	scrTime = ".$scrTime.", scrUpdated = NOW() WHERE scrid = ".(int)$_GET["scrid"]."";
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-success mt-5">
	  <strong>Success!</strong> Item updated.
	</div>';
}
$pageTitle = "Cinema | Screenings";
include_once("header.php");
?>
<form action="" method="post" id="frmScreening" name="frmScreening">
<div class="container py-5">
	<div class="row text-center">
		<div class="col-sm-10 mx-auto">
			<h1 class="colorBlue styleFont mt-5 mb-3">Screenings records</h1>
			<?php if($Option == "AddNew"){?>
				<div class="row text-left">
					<div class="col-sm-6 py-4 bgColorBlack mx-auto">
						<input type="hidden" id="Option" name="Option" value="Insert" />
						<div class="form-group colorWhite">
							<select class="form-control" id="mid" name="mid" required>
							<option value="" selected >Select movie</option>
							<?php
							$strSQL = "SELECT mid, mName FROM tbMovies WHERE mActive = 1";
							//echo "strSQL = $strSQL<br />\n";
							$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
							while($row = mysqli_fetch_assoc($rez)){
								?>
								<option value="<?php $row["mid"]?>"><?php $row["mName"]?></option>
								<?php
							}
							?>
							</select>
						</div>
						<div class="form-group colorWhite">
							<select class="form-control" id="mrid" name="mrid" required>
							<option value="" selected >Select movie room</option>
							<?php
							$strSQL = "SELECT mrid, mrName FROM tbMovieRooms";
							//echo "strSQL = $strSQL<br />\n";
							$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
							while($row = mysqli_fetch_assoc($rez)){
								?>
								<option value="<?=$row["mrid"]?>"><?=$row["mrName"]?></option>
								<?php
							}
							?>
							</select>
						</div>
						<div class="form-group colorWhite">
							<label for="scrTicketPrice">Ticket price:</label>
							<input type="number" class="form-control" placeholder="Ticket price" name="scrTicketPrice" id="scrTicketPrice" required/>
						</div>
						<div class="form-group colorWhite">
							<label for="scrDate">Screening date:</label>
							<input type="date" class="form-control" placeholder="Screening date" name="scrDate" id="scrDate" required/>
						</div>
						<div class="form-group colorWhite">
							<label for="scrHour">Screening hour:</label>
							<input type="text" class="form-control" placeholder="Screening time" name="scrHour" id="scrHour" required/>
						</div> 
						<button type="submit" class="btn btnColor">Add</button>
					</div>
				</div>
			<?php }elseif($Option == "View"){
				$strSQL = "SELECT mName, gids, mLength, mSummary FROM tbMovies WHERE mid = ".(int)$_GET["mid"];
				//echo "strSQL = $strSQL<br />\n";
				$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
				while($row = mysqli_fetch_assoc($rez)){
					$arrGenres = array();
					if(!empty($row["gids"])){
						$strSQL = "SELECT gName FROM tbGenres WHERE gid IN (".$row["gids"].")";
						//echo "strSQL = $strSQL<br />\n";
						$tmpRez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
						while($tmpRow = mysqli_fetch_assoc($tmpRez)){
							$arrGenres[] = $tmpRow["gName"];
						}
					}
					?>
					<div class="container py-5">
						<h1 class="colorBlue styleFont mt-2 mb-3 text-center">Movie details</h1>
						<div class="row mx-auto py-5 bgColorBlack">
							<div class="col-sm-4">
								<img class="img-fluid" src="../img/movie-<?=$_GET["mid"]?>.jpg"/>
							</div>
							<div class="col-sm-4 colorWhite">
								<h5><?php $row["mName"]?></h5>
								<h6><?php implode(", ", $arrGenres)?></h6>	
								<h6><?php $row["mLength"]." min"?></h6>
							</div>
							<div class="col-sm-4 colorWhite">
								<h6><?php nl2br($row["mSummary"])?></h6>	
							</div>
						</div>
					</div>
					<?php
				}	
			}elseif($Option == "Edit"){
					$strSQL = "SELECT scr.scrTicketPrice, scr.scrTime, mr.mrid FROM tbScreenings scr JOIN tbMovieRooms mr
					ON scr.mrid = mr.mrid WHERE scr.scrid = ".(int)$_GET["scrid"];
					//echo "strSQL = $strSQL<br />\n";
					$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
					if($row = mysqli_fetch_assoc($rez)){
						extract($row);
						?>
						<div class="row text-left">
							<div class="col-sm-6 py-4 bgColorBlack mx-auto">
								<input type="hidden" id="Option" name="Option" value="Update" />
								<input type="hidden" id="scrid" name="scrid" value="<?=$_GET["scrid"]?>" />
								<div class="form-group colorWhite">
									<select class="form-control" id="mid" name="mid" required>
									<option value="" selected >Select movie</option>
									<?php
									$strSQL = "SELECT mid, mName FROM tbMovies WHERE mActive = 1";
									//echo "strSQL = $strSQL<br />\n";
									$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
									while($row = mysqli_fetch_assoc($rez)){
										?>
										<option value="<?php $row["mid"]?>"><?php $row["mName"]?></option>
										<?php
									}
									?>
									</select>
								</div>
								<div class="form-group colorWhite">
									<label class="colorWhite ml-2" for="mrid">Select movie room:</label>
									<select class="form-control mb-3" id="mrid" name="mrid" required>
									<option value=""<?php (empty($mrid) ? ' selected="selected"' : '')?>>Choose ..</option>
									<?php
									$strSQL = "SELECT mrid, mrName FROM tbMovieRooms";
									//echo "strSQL = $strSQL<br />\n";
									$rez1 = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
									while($row1 = mysqli_fetch_assoc($rez1)){
										?>
										<option value="<?php $row1["mrid"]?>"<?php ($mrid==$row1["mrid"] ? ' selected="selected"' : '')?>><?php $row1["mrName"]?></option>
										<?php
									}
									?>
									</select>
								</div>
								<div class="form-group colorWhite">
									<label for="scrTicketPrice">Ticket price:</label>
									<input type="number" class="form-control" placeholder="Ticket price" name="scrTicketPrice" id="scrTicketPrice" step="0.01" value="<?php sprintf("%01.2f",$scrTicketPrice)?>" required/>
								</div>
								<div class="form-group colorWhite">
									<label for="scrDate">Screening date:</label>
									<input type="date" class="form-control" placeholder="Screening date" name="scrDate" id="scrDate" 
									value="<?php date("Y-m-d", strtotime($scrTime))?>" required/>
								</div>
								<div class="form-group colorWhite">
									<label for="scrHour">Screening hour:</label>
									<input type="text" class="form-control" placeholder="Screening time" name="scrHour" id="scrHour" 
									value="<?php date("H:i", strtotime($scrTime))?>" required/>
								</div> 
								<button type="submit" class="btn btnColor">Update</button>
							</div>
						</div>
					<?php
					}else{
						?>
						<div class="alert alert-warning mt-5">
						  <strong>Note!</strong> Item missing.
						</div>
						<?php
					}
			}else{?>
				
				<div class="table-responsive">
					<table class="table table-dark table-hover table-bordered text-center">
						<thead class="thead-dark">
							<tr>
								<th>Screening time</th>
								<th>Screening active status</th>
								<th>Movie name</th>
								<th>Ticket price</th>
								<th>Movie room</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$strSQL = "SELECT scr.scrid, scr.scrTime,scr.scrTicketPrice, scr.scrActive, m.mid, m.mName, mr.mrName FROM tbScreenings scr JOIN tbMovies m ON scr.mid = m.mid JOIN tbMovieRooms mr ON scr.mrid = mr.mrid";
						//echo "strSQL = $strSQL<br />\n";
						$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
						while($row = mysqli_fetch_assoc($rez)){
							?>
							<tr>
								<td><?=$row["scrTime"]?></td>
								<td><?=(!empty($row["scrActive"]) ? "ACTIVE" : "INACTIVE")?></td>
								<td><?=$row["mName"]?></td>
								<td><?=$row["scrTicketPrice"]?></td>
								<td><?=$row["mrName"]?></td>
								<td nowrap>
									<?php if(empty($row["scrActive"])){?>
										<button class="btn btn-success btn-sm" onclick="if(confirm('Do you really want to Activate the selected item?')){location='?Option=Activate&scrid=<?php $row["scrid"]?>'}"><i class="fas fa-check-circle"></i></i>
									<?php }else{?>
										<button class="btn btn-danger btn-sm" onclick="if(confirm('Do you really want to Deactivate the selected item?')){location='?Option=Deactivate&scrid=<?php $row["scrid"]?>'}"><i class="fas fa-trash-alt "></i>
									<?php }?>
									</button>
								</td>
							</tr>
							<?php
						}
						?>
						</tbody>
					</table>
				</div>
			<?php }?>
		</div>
	</div>
	<?php $msg?>
</div>
</form>
<script>
$(function(){
	$("#frmScreening").validate({
	rules:{
		mid:"required",
		mrid:"required",
		scrTicketPrice:"required",
		scrDate:"required",
		scrHour:"required"
	},
	messages:{
		mid:"Enter movie name",
		mrid:"Enter movie room name",
		scrTicketPrice:"Enter ticket price",
		scrDate:"Enter screening date",
		scrHour:"Enter screening hour"
	},
	submitHandler: function(form) {
	form.submit();
		}
	});
});
</script>
<?php
include_once("../footer.php");
?>