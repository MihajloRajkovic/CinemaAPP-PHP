<?php
if (!isset($_SESSION)) {
    session_start();
  }
require_once("../conn.php");

if(empty($_SESSION["uid"])){
	header("location: ./login.php");
	exit;
}
if(empty($_SESSION["uRole"])){
	header("location: ../");
	exit;
}
$pageTitle = "Cinema | Home";
include_once("header.php");
?>
<section class="py-4">
	<div class="container py-5">
		<div class="row text-center py-5">
			<div class="col-sm-6 py-5 mx-auto">
			<h1 class="colorBlue styleFont my-5">Welcome admin!</h1>
			</div>
		</div>
	</div>
</section>
<?php
include_once("../footer.php");
?>