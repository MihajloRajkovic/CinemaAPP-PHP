<?php
if (!isset($_SESSION)) {
    session_start();
  }
$scriptName = basename(__FILE__);
require_once("../conn.php");

if(!empty($_SESSION["uRole"])){
	header("location: ./");
	exit;
}

$Option = !empty($_GET["Option"])? $_GET["Option"] : "";
$Option = !empty($_POST["Option"])? $_POST["Option"] : $Option;

$mess	= "";
if($Option == "Login"){
	$mess = '
	<div class="alert alert-warning mt-3">
		<strong>Note!</strong> Wrong login data!
	</div>';
	$strSQL = "SELECT uid, uPass FROM tbUsers WHERE uRole = 1 AND uEmail = '".mysqli_real_escape_string($conn,stripslashes($_POST["uEmail"]))."'";
	//echo "strSQL = $strSQL<br />\n";
	$rez= mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){ 
		if(md5($_POST["uPass"])==$row["uPass"]){
			$_SESSION["uid"] = $row["uid"];
			$_SESSION["uRole"] = 1;
			header("location: ./");
			exit;
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head profile="http://www.w3.org/2005/10/profile">
<title>Cinema | Login</title>
  <link rel="icon" type="image/png" href="../img/favicon.ico">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="../css/cinema_css.css">
  <!--Font awesome-->
  <script src="//use.fontawesome.com/releases/v5.12.0/js/all.js" data-auto-replace-svg="nest"></script>
  <!--Google fonts-->
  <link href="//fonts.googleapis.com/css2?family=Oswald:wght@300&display=swap" rel="stylesheet">
  <link href="//fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
  <!--end of Google fonts-->
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <!--ajax and jquery-->
  <script src="//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <!--ajax and jquery-->
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
	<h1 class="text-center">Login</h1>
	<div class="row">
		<div class="col-sm-6 py-4 bgColorBlack mx-auto">
			<form action="" method="post" name="loginFormAdmin" id="loginFormAdmin">
				<input type="hidden" name="Option" id="Option" value="Login"/>
				<div class="form-group colorWhite">
					<label for="uEmail">Email:</label>
					<input type="email" class="form-control" placeholder="Email" name="uEmail" id="uEmail" required/>
					
				</div>
				<div class="form-group colorWhite">
					<label for="uPass">Password:</label>
					<input type="password" class="form-control" placeholder="Password" name="uPass" id="uPass" required/>
				</div>
				<button type="submit" class="btn btnColor">Login</button>
			</form>
		</div>
	</div>
   <?php $mess?>
</div>
<script>
$(function(){
	$("#loginFormAdmin").validate({
		rules:{
		  uPass: {
			required: true,
		  },
		  uEmail: {
			required: true,
			email: true
		  }
		},
		messages: {
			uPass:{
				required:"Enter password.",
			},
			uEmail:{
				required:"Enter email adress.",
				email:"Enter a valid email adress."
			}
		},
		submitHandler: function(form) {
		form.submit();
		}
	});
});
</script>
</body>
</html>