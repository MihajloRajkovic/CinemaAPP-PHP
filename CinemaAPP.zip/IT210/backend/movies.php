<?php
if (!isset($_SESSION)) {
    session_start();
  }
require_once("../conn.php");

if(!empty($_SESSION["uid"]) AND ($_SESSION["uRole"] == 0)){
	header("location: ../");
	exit;
}

$Option	= !empty($_GET["Option"]) ? $_GET["Option"] : "";
$Option	= !empty($_POST["Option"]) ? $_POST["Option"] : $Option;
$mid	= !empty($_GET["mid"]) ? (int)$_GET["mid"] : 0;
$mid	= !empty($_POST["mid"]) ? (int)$_POST["mid"] : $mid;

$msg = '';
if($Option == "Deactivate"){
	$strSQL = "UPDATE tbMovies SET mActive = 0, mUpdated = NOW() WHERE mid = ".(int)$_GET["mid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-danger mt-5">
	  <strong>Warning!</strong> Item Deactivated.
	</div>';
}elseif($Option == "Activate"){
	$strSQL = "UPDATE tbMovies SET mActive = 1, mUpdated = NOW() WHERE mid = ".(int)$_GET["mid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-success mt-5">
	  <strong>Success!</strong> Item Activated.
	</div>';
}elseif($Option == "Insert"){
	$mName = $_POST["mName"];
	$strSQL = "SELECT mid FROM tbMovies WHERE mName = '".mysqli_real_escape_string($conn,stripslashes($mName))."'";
	//echo "strSQL = $strSQL<br />\n";
	$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){
		$msg = '
		<div class="alert alert-danger mt-3">
			<strong>Note!</strong> That movie already exists!
		</div>';
	}else{
		$gids = count($_POST["gid"]) ? implode(",",$_POST["gid"]) : "";
		$strSQL = "INSERT INTO tbMovies SET mName = '".mysqli_real_escape_string($conn,stripslashes($mName))."',
		gids = '".$gids."', mLength = ".(int)$_POST["mLength"].", mSummary = '".$_POST["mSummary"]."', mCreated = NOW()";
		//echo "strSQL = $strSQL<br />\n";
		$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
		$msg = '
		<div class="alert alert-success mt-3">
			<strong>Sucess!</strong> Movie added.
		</div>';
	}
}elseif($Option == "Update"){
	$bUpdate = true;
	$mName = $_POST["mName"];
	$strSQL = "SELECT mid FROM tbMovies WHERE mName = '".mysqli_real_escape_string($conn,stripslashes($mName))."'";
	//echo "strSQL = $strSQL<br />\n";
	$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){
		if($row["mid"]!=$mid){
			$msg = '
			<div class="alert alert-danger mt-3">
				<strong>Note!</strong> That movie already exists!
			</div>';
			$bUpdate = false;
			$Option = "Edit";
		}
	}
	if($bUpdate){
		//echo "_POST<pre>";print_r($_POST);echo "</pre>";
		$gids = count($_POST["gid"]) ? implode(",",$_POST["gid"]) : "";
		$strSQL = "UPDATE tbMovies SET mName = '".mysqli_real_escape_string($conn,stripslashes($mName))."',
		gids = '".$gids."', mLength = ".(int)$_POST["mLength"].", mSummary = '".$_POST["mSummary"]."', mUpdated = NOW() WHERE mid = ".(int)$mid;
		//echo "strSQL = $strSQL<br />\n";
		mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
		$msg = '
		<div class="alert alert-sucess mt-3">
			<strong>Sucess!</strong> Movie added.
		</div>';
	}
}
$pageTitle = "Cinema | Movies";
include_once("header.php");
?>
<form action="" method="post" id="frmMovie" name="frmMovie">
<div class="container py-5">
	<div class="row text-center">
		<div class="col-sm-10 mx-auto">
			<h1 class="colorBlue styleFont mt-5 mb-3">Movies records</h1>
			<?php if($Option == "AddNew"){?>
				<div class="row text-left">
					<div class="col-sm-6 py-4 bgColorBlack mx-auto">
						<input type="hidden" id="Option" name="Option" value="Insert" />
						<div class="form-group colorWhite">
							<label for="mName">Movie name:</label>
							<input type="text" class="form-control" placeholder="Movie name" name="mName" id="mName" required/>
						</div>
						<div class="form-group colorWhite">
							<label for="gid">Select genre(or genres):</label>
							<select class="form-control" id="gid" name="gid[]" size="10" multiple required>
							<option value="" selected >Choose..</option>
							<?php
							$strSQL = "SELECT gid, gName FROM tbGenres";
							//echo "strSQL = $strSQL<br />\n";
							$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
							while($row = mysqli_fetch_assoc($rez)){
								?>
								<option value="<?php $row["gid"]?>"><?php $row["gName"]?></option>
								<?php
							}
							?>
							</select>
						</div>
						<div class="form-group colorWhite">
							<label for="mLength">Movie length:</label>
							<input type="number" class="form-control" placeholder="Movie length" name="mLength" id="mLength" required/>
						</div>
						<div class="form-group colorWhite">
							<label for="mSummary">Plot summary:</label>
							<textarea class="form-control" name="mSummary" rows="5" required></textarea>
						</div> 
						<!--
						<div class="form-group colorWhite">
							<label for="img">Movie poster:</label>
							<input type="file" class="form-control" id="img" name="img" accept="file_extension/*.jpg|image/*" required>
						</div> 
						-->
						<button type="submit" class="btn btnColor" id="addBtn">Add</button>
					</div>
				</div>
				<?php
			}elseif($Option == "Edit"){
				$strSQL = "SELECT * FROM tbMovies WHERE mid = ".(int)$_GET["mid"];
				//echo "strSQL = $strSQL<br />\n";
				$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
				if($row = mysqli_fetch_assoc($rez)){
					extract($row);
					$gids = !empty($gids) ? explode(",", $gids) : array();
					?>
					<div class="row text-left">
						<div class="col-sm-6 py-4 bgColorBlack mx-auto">
							<input type="hidden" id="Option" name="Option" value="Update" />
							<input type="hidden" id="mid" name="mid" value="<?php $_GET["mid"]?>" />
							<div class="form-group colorWhite">
								<label for="mName">Movie name:</label>
								<input type="text" class="form-control" placeholder="Movie name" name="mName" id="mName" value="<?php $mName?>" required/>
							</div>
							<div class="form-group colorWhite">
								<label for="gid">Select genre(or genres):</label>
								<select class="form-control" id="gid" name="gid[]" size="10" multiple required>
								<option value=""<?php (empty($gids) ? ' selected="selected"' : '')?>>Choose..</option>
								<?php
								$strSQL = "SELECT gid, gName FROM tbGenres";
								//echo "strSQL = $strSQL<br />\n";
								$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
								while($row = mysqli_fetch_assoc($rez)){
									?>
									<option value="<?php $row["gid"]?>"<?php (in_array($row["gid"], $gids) ? ' selected="selected"' : '')?>><?=$row["gName"]?></option>
									<?php
								}
								?>
								</select>
							</div>
							<div class="form-group colorWhite">
								<label for="mLength">Movie length:</label>
								<input type="number" class="form-control" placeholder="Movie length" name="mLength" id="mLength" value="<?php $mLength?>" required/>
							</div>
							<div class="form-group colorWhite">
								<label for="mSummary">Plot summary:</label>
								<textarea class="form-control" name="mSummary" rows="5" required><?php $mSummary?></textarea>
							</div> 
							<button type="submit" class="btn btnColor" id="updateBtn">Update</button>
						</div>
					</div>
					<?php
				}else{
					?>
					<div class="alert alert-warning mt-5">
					  <strong>Note!</strong> Item missing.
					</div>
					<?php
				}
			}else{?>
				
				<div class="table-responsive">
					<table class="table table-dark table-hover table-bordered text-center">
						<thead class="thead-dark">
							<tr>
								<th>Movie name</th>
								<th>Movie active status</th>
								<th>Movie genres</th>
								<th>Movie length</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$strSQL = "SELECT mid, mName, mActive, gids, mLength FROM tbMovies";
						//echo "strSQL = $strSQL<br />\n";
						$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
						while($row = mysqli_fetch_assoc($rez)){
							$arrGenres = array();
							if(!empty($row["gids"])){
								$strSQL = "SELECT gName FROM tbGenres WHERE gid IN (".$row["gids"].")";
								//echo "strSQL = $strSQL<br />\n";
								$tmpRez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
								while($tmpRow = mysqli_fetch_assoc($tmpRez)){
									$arrGenres[] = $tmpRow["gName"];
								}
							}
							?>
							<tr>
								<td><?=$row["mName"]?></td>
								<td><?=(!empty($row["mActive"]) ? "ACTIVE" : "INACTIVE")?></td>
								<td><?=implode(", ", $arrGenres)?></td>
								<td><?=$row["mLength"]?></td>
								<td nowrap>
									
									<?php if(empty($row["mActive"])){?>
										<button class="btn btn-success btn-sm" onclick="if(confirm('Do you really want to Activate the selected item?')){location='?Option=Activate&mid=<?=$row["mid"]?>'}"><i class="fas fa-check-circle"></i></i>
									<?php }else{?>
										<button class="btn btn-danger btn-sm" onclick="if(confirm('Do you really want to Deactivate the selected item?')){location='?Option=Deactivate&mid=<?=$row["mid"]?>'}"><i class="fas fa-trash-alt "></i>
									<?php }?>
									</button>
								</td>
							</tr>
							<?php
						}
						?>
						</tbody>
					</table>
				</div>
			<?php }?>
		</div>
	</div>
	<?php $msg?>
</div>
</form>
<script>
$(function(){
	$("#frmMovie").validate({
		rules:{
			mName:"required",
			gid:"required",
			mLength:"required",
			mSummary:"required"
		},
		messages:{
			mName:"Enter movie name",
			gid:"Enter movie genre(s)",
			mLength:"Enter movie length",
			mSummary:"Enter plot summary"
		},
		submitHandler: function(form) {
			form.submit();
		}
	});
});
</script>
<?php
include_once("../footer.php");
?>