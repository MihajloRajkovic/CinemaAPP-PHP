<?php
if (!isset($_SESSION)) {
    session_start();
  }
require_once("../conn.php");

if(!empty($_SESSION["uid"]) AND ($_SESSION["uRole"] == 0)){
	header("location: ../");
	exit;
}

$Option	= !empty($_GET["Option"]) ? $_GET["Option"] : "";
$Option	= !empty($_POST["Option"]) ? $_POST["Option"] : $Option;
$mrid	= !empty($_GET["mrid"]) ? (int)$_GET["mrid"] : 0;
$mrid	= !empty($_POST["mrid"]) ? (int)$_POST["mrid"] : $mrid;

$msg = '';
if($Option == "Deactivate"){
	$strSQL = "UPDATE tbMovieRooms SET mrActive = 0, mrUpdated = NOW() WHERE mrid = ".(int)$_GET["mrid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-danger mt-5">
	  <strong>Warning!</strong> Item Deactivated.
	</div>';
}elseif($Option == "Activate"){
	$strSQL = "UPDATE tbMovieRooms SET mrActive = 1, mrUpdated = NOW() WHERE mrid = ".(int)$_GET["mrid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-success mt-5">
	  <strong>Success!</strong> Item Activated.
	</div>';
}elseif($Option == "Insert"){
	$mrName = $_POST["mrName"];
	$strSQL = "SELECT mrid FROM tbMovieRooms WHERE mrName = '".mysqli_real_escape_string($conn,stripslashes($mrName))."'";
	//echo "strSQL = $strSQL<br />\n";
	$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){
		$msg = '
		<div class="alert alert-danger mt-3">
			<strong>Note!</strong> That movie room already exists!
		</div>';
	}else{
		$strSQL = "INSERT INTO tbMovieRooms SET mrName = '".mysqli_real_escape_string($conn,stripslashes($mrName))."',
		mrCapacity = ".(int)$_POST["mrCapacity"].", mrCreated = NOW()";
		//echo "strSQL = $strSQL<br />\n";
		$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
		$msg = '
		<div class="alert alert-success mt-3">
			<strong>Sucess!</strong> Movie room added.
		</div>';
	}
}elseif($Option == "Update"){
	$bUpdate = true;
	$mName = $_POST["mrName"];
	$strSQL = "SELECT mid FROM tbMovies WHERE mrName = '".mysqli_real_escape_string($conn,stripslashes($mName))."'";
	//echo "strSQL = $strSQL<br />\n";
	$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){
		if($row["mrid"]!=$mrid){
			$msg = '
			<div class="alert alert-danger mt-3">
				<strong>Note!</strong> That movie room already exists!
			</div>';
			$bUpdate = false;
			$Option = "Edit";
		}
	}
	if($bUpdate){
		//echo "_POST<pre>";print_r($_POST);echo "</pre>";
		$strSQL = "UPDATE tbMovieRooms SET mrName = '".mysqli_real_escape_string($conn,stripslashes($mrName))."',
		mrCapacity = ".(int)$_POST["mrCapacity"].", mrUpdated = NOW() WHERE mrid = ".(int)$mrid;
		//echo "strSQL = $strSQL<br />\n";
		mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
		$msg = '
		<div class="alert alert-sucess mt-3">
			<strong>Sucess!</strong> Movie room added.
		</div>';
	}
}
$pageTitle = "Cinema | Movie rooms";
include_once("header.php");
?>
<form action="" method="post" id="frmMovieRooms" name="frmMovieRooms">
<div class="container py-5">
	<div class="row text-center">
		<div class="col-sm-10 mx-auto">
			<h1 class="colorBlue styleFont mt-5 mb-3">Movie rooms records</h1>
			<?php if($Option == "AddNew"){?>
				<div class="row text-left">
					<div class="col-sm-6 py-4 bgColorBlack mx-auto">
						<input type="hidden" id="Option" name="Option" value="Insert" />
						<div class="form-group colorWhite">
							<label for="mrName">Movie room name:</label>
							<input type="text" class="form-control" placeholder="Movie room name" name="mrName" id="mrName" required/>
						</div>
						<div class="form-group colorWhite">
							<label for="mrCapacity">Movie room capacity:</label>
							<input type="number" class="form-control" placeholder="Movie room capacity" name="mrCapacity" id="mrCapacity" required/>
						</div>
						<button type="submit" class="btn btnColor" id="addBtn">Add</button>
					</div>
				</div>
				<?php }elseif($Option == "Edit"){
					$strSQL = "SELECT * FROM tbMovieRooms WHERE mrid = ".(int)$_GET["mrid"];
					//echo "strSQL = $strSQL<br />\n";
					$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
					if($row = mysqli_fetch_assoc($rez)){
					extract($row);
					?>
					<div class="row text-left">
						<div class="col-sm-6 py-4 bgColorBlack mx-auto">
							<input type="hidden" id="Option" name="Option" value="Update" />
							<input type="hidden" id="mrid" name="mrid" value="<?php $_GET["mrid"]?>" />
							<div class="form-group colorWhite">
								<label for="mrName">Movie room name:</label>
								<input type="text" class="form-control" placeholder="Movie room name" name="mrName" id="mrName" value="<?php $mrName?>" required/>
							</div>
							<div class="form-group colorWhite">
								<label for="mrCapacity">Movie room capacity:</label>
								<input type="number" class="form-control" placeholder="Movie room capacity" name="mrCapacity" id="mrCapacity" value="<?php $mrCapacity?>" required/>
							</div>
							<button type="submit" class="btn btnColor">Update</button>
						</div>
					</div>
					<?php
					}else{
						?>
						<div class="alert alert-warning mt-5">
						  <strong>Note!</strong> Item missing.
						</div>
						<?php
					}
				}else{?>
					
					<div class="table-responsive">
						<table class="table table-dark table-hover table-bordered text-center">
							<thead class="thead-dark">
								<tr>
									<th>Movie room name</th>
									<th>Movie room active status</th>
									<th>Movie room capacity</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php
							$strSQL = "SELECT * FROM tbMovieRooms";
							//echo "strSQL = $strSQL<br />\n";
							$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
							while($row = mysqli_fetch_assoc($rez)){
								?>
								<tr>
									<td><?=$row["mrName"]?></td>
									<td><?=(!empty($row["mrActive"]) ? "ACTIVE" : "INACTIVE")?></td>
									<td><?php ["mrCapacity"]?></td>
									<td nowrap>
										
										<?php if(empty($row["mrActive"])){?>
											<button class="btn btn-success btn-sm" onclick="if(confirm('Do you really want to Activate the selected item?')){location='?Option=Activate&mrid=<?php $row['mrid'] ?>'}"><i class="fas fa-check-circle"></i></i>
										<?php }else{?>
											<button class="btn btn-danger btn-sm" onclick="if(confirm('Do you really want to Deactivate the selected item?')){location='?Option=Deactivate&mrid=<?php $row['mrid'] ?>'}"><i class="fas fa-trash-alt "></i>
										<?php }?>
										</button>
									</td>
								</tr>
								<?php
							}
							?>
							</tbody>
						</table>
					</div>
				<?php }?>
		</div>
	</div>
	<?=$msg?>
</div>
</form>
<script>
$(function(){
	$("#frmMovieRooms").validate({
		rules:{
			mrName:"required",
			mrCapacity:"required"
		},
		messages:{
			mrName:"Enter movie room name",
			mrCapacity:"Enter movie room capacity"
		},
		submitHandler: function(form) {
			form.submit();
		}
	});
});
</script>
<?php
include_once("../footer.php");
?>