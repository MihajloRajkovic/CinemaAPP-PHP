<!--footer-->
<footer class="bgColorPurple py-3">
	<div class="container">
		<div class="row">
			<div class="col-sm-4 text-center mb-2">
				<h5 class="colorWhite mb-4">Follow us</h5>
				<div class="d-flex justify-content-around">
					<a href="https://www.facebook.com/" target="_blank">
					<i class="fab fa-facebook-square fa-2x colorBlue"></i>
					</a>
					<a href="https://www.instagram.com/?hl=sr" target="_blank">
					<i class="fab fa-instagram fa-2x colorBlue"></i>
					</a>
					<a href="https://twitter.com/login?lang=sr" target="_blank">
					<i class="fab fa-twitter-square fa-2x colorBlue"></i>
					</a>
				</div>
			</div>
			<div class="col-sm-4 text-center mb-2">
				<h5 class="colorWhite">Contact</h5>
				<h6 class="colorBlack">Serbia</h6>
				<h6 class="colorBlack"><strong>email: </strong>cinema@gmail.com</h6>
				<h6 class="colorBlack"><strong>Telephone for reservations: </strong></h6>
				<h6 class="colorBlack">0123456789</h6>
			</div>
			<div class="col-sm-4 text-center mb-2">
				<h6 class="colorWhite">Time when you can make a reservation:</h6>
				<h6 class="colorBlack"><strong>Weekdays: </strong>10:00-22:00h</h6>
				<h6 class="colorBlack"><strong>Weekend: </strong>12:00-21:00h</h6>
			</div>
		</div>
	</div>
</footer>
<!--end of footer-->
</body>
</html>
<?php mysqli_close($conn)?>