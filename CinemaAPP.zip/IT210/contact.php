<?php
include_once("header.php");
if (!isset($_SESSION)) {
    session_start();
  }
$scriptName = basename(__FILE__);
require_once("conn.php");
require_once("con2.php");
$pageTitle = "Cinema | Contact";
?>

<?php 
    if (isset($_POST['form'])) {
        $ime = mysqli_real_escape_string($conn,$_POST['ime']);
        $prezime =mysqli_real_escape_string($conn,$_POST['prezime']); 
        $broj1 = mysqli_real_escape_string($conn,$_POST['broj1']);
        $poruka = mysqli_real_escape_string($conn,$_POST['poruka']);
        if (!empty($_POST['poruka'])) {
        $stmt = $con->prepare("INSERT INTO `poruke`(`ime`, `prezime`, `broj`, `poruka`) 
        VALUES (?,?,?,?)");   
        $stmt->execute(array($ime, $prezime, $broj1, $poruka));
        header("Location:/IT210-Projekat/IT210/contact.php");
        }
    }
?>
<style>
    .div1 {
    width: 50%;
    float: right;
    padding: 100px;
}
.forma {
    width: 50%;
    padding: 100px;
}
</style>

    <div class="div1">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d1591.108748920228!2d21.91808922565196!3d42.99709592431052!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2srs!4v1641851505147!5m2!1sen!2srs" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>

    <div class="forma">
        <p>Posaljite poruku ovde:</p>
        <form action="contact.php" method="post">   
        <input type="input" placeholder="Ime" id="ime1" name="ime" required />
            <br>
            <br>
            <input type="input" placeholder="Prezime" id="prezime1" name="prezime" required />
            <br>
            <br>
            <input type="input" placeholder="Telefon" id="broj1" name="broj1" required />
            <br>
            <br>
            <textarea id="deozatext" cols="30" rows="5" placeholder="Unesite poruku..." onmousedown="" name="poruka"></textarea>
            <br>
            <br>
            <label id="label">Sadrzaj poruke:</label>
            <select name="proizvodi" id="button">
                <option value="problem">Za probleme</option>
                <option value="pomoc">Za dodatne informacije</option>
            </select>
            <input type="submit" value="Posalji" name="form"><br>
            <br>
        </form>
    </div>
    <br><br><br><br><br><br><br>
<?php include_once("footer.php")?>
