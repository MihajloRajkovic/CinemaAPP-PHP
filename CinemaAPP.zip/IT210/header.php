<!DOCTYPE html>
<html lang="en">
<head profile="http://www.w3.org/2005/10/profile">	
  <link rel="icon" type="image/png" href="./img/favicon.ico">
  <title> Cinema</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="./css/cinema_css.css">
  <!--Font awesome-->
  <script src="//use.fontawesome.com/releases/v5.12.0/js/all.js" data-auto-replace-svg="nest"></script>
  <!--Google fonts-->
  <link href="//fonts.googleapis.com/css2?family=Oswald:wght@300&display=swap" rel="stylesheet">
  <link href="//fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
  <!--end of Google fonts-->
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <!--ajax and jquery-->
  <script src="//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <!--ajax and jquery-->
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<!--navbar-->
<nav class="navbar navbar-dark navbar-expand-sm bgColorBlack fixed-top">
	<div class="navbar-brand colorBlue styleFont">CINEMA</div>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navBar">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navBar">
		<ul class="navbar-nav">
			<li class="nav-item active">
				<a href="./" class="nav-link">Home</a>
			</li>
			<li class="nav-item active">
			<a href="login.php" class="nav-link">Login</a></li>
			<li class="nav-item active">
			<a href="contact.php" class="nav-link">Contact</a></li>
			<?php if(!empty($_SESSION["uid"])){?>
			<li class="nav-item">
				<div class="dropdown">
				  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">My account
				  <span class="caret"></span></button>
				  <ul class="dropdown-menu">
					<li><a href="history.php">History</a></li>
					<li><a href="logout.php">Logout</a></li>
				  </ul>
				</div>
			</li>
			
			<?php
			}
			?>
		</ul>
	</div>
</nav>	
<!-- end of navbar -->