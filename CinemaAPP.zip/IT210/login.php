<?php

if (!isset($_SESSION)) {
    session_start();
  }
$scriptName = basename(__FILE__);
require_once("conn.php");

if(!empty($_SESSION["uid"])){
	header("location: ./");
	exit;
}
$BackURL	= !empty($_SESSION["BackURL"]) ? $_SESSION["BackURL"] : "";
$BackURL	= !empty($_GET["BackURL"]) ? $_GET["BackURL"] : $BackURL;
$BackURL	= !empty($_POST["BackURL"]) ? $_POST["BackURL"] : $BackURL;
$_SESSION["BackURL"] = $BackURL;

$BackOption	= !empty($_SESSION["BackOption"]) ? $_SESSION["BackOption"] : "";
$BackOption	= !empty($_GET["BackOption"]) ? $_GET["BackOption"] : $BackOption;
$BackOption	= !empty($_POST["BackOption"]) ? $_POST["BackOption"] : $BackOption;
$_SESSION["BackOption"] = $BackOption;

if(!empty($_GET["BackURL"])){
	header("location: ./".$scriptName);
	exit;
}

$Option = !empty($_GET["Option"])? $_GET["Option"] : "";
$Option = !empty($_POST["Option"])? $_POST["Option"] : $Option;

$mess = "";

if($Option == "Login"){
	$uEmail = $_POST["uEmail"];
	$uPass = $_POST["uPass"];
	$strSQL = "SELECT * FROM tbUsers WHERE  uEmail='".mysqli_real_escape_string($conn,stripslashes($uEmail))."'";
	//echo "strSQL = $strSQL<br />\n";
	$rez= mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if($row = mysqli_fetch_assoc($rez)){ 
		if(md5($uPass)==$row["uPass"]){
			$_SESSION["uid"] = $row["uid"];
			$_SESSION["uRole"] = $row["uRole"];
			$strNewURL = "./";
			if(!empty($_SESSION["BackURL"])){
				$strNewURL = $_SESSION["BackURL"];
				unset($_SESSION["BackURL"]);
			}
			if(!empty($_SESSION["BackOption"])){
				$strNewURL .= "?Option=".$_SESSION["BackOption"];
				unset($_SESSION["BackOption"]);
			}if($row["uRole"]==0){
				header("location: ".$strNewURL);
			}else{
				header("location:backend/index.php ");
			}
			
			exit;
		}else{
			$mess = '
			<div class="alert alert-warning mt-3">
				<strong>Note!</strong> Wrong login data!
			</div>';
		}
	}else{
		$mess = '
		<div class="alert alert-warning mt-3">
			<strong>Note!</strong> Wrong login data!
		</div>';
	}
}
$pageTitle = "Cinema | Login";
include_once("header.php");
?>
<section class="bgColorWhite py-5">
	<div class="container">
		<h1 class="colorBlue text-center py-4 styleFont">Login</h1>
		<div class="row">
			<div class="col-sm-6 py-4 bgColorBlack mx-auto">
				<form action="" method="post" name="loginForm" id="loginForm">
					<input type="hidden" name="Option" id="Option" value="Login"/>
					<div class="form-group colorWhite">
						<label for="uEmail">Email:</label>
						<input type="email" class="form-control" placeholder="Email" name="uEmail" id="uEmail" required/>	
					</div>
					<div class="form-group colorWhite">
						<label for="uPass">Password:</label>
						<input type="password" class="form-control" placeholder="Password" minlength="5" name="uPass" id="uPass" required/>
					</div>
					<h6 class="colorBlue text-right">Required fields*</h6>
					<button type="submit" class="btn btnColor">Login</button>
					<h6 class="colorWhite mt-3">Don't have an account? <a class="colorBlue" href="register.php">Register</a></h6>
				</form>
			</div>
		</div>
	   <?php $mess?>
	</div>
</section>
<script>
$(function(){
	$("#loginForm").validate({
		rules:{
		  uPass: {
			required: true,
			minlength:5
		  },
		  uRepeatPass: {
			required: true,
			minlength:5
		  },
		  uEmail: {
			required: true,
			email: true
		  }
	    },
		messages: {
			uPass:{
				required:"Please enter your password.",
				minlength:"Password must be at least 5 characters long."
			},
			uRepeatPass:{
				required:"Please enter your password.",
				minlength:"Password must be at least 5 characters long."
			},
			uEmail:{
				required:"Please enter your email adress.",
				email:"Please enter a valid email adress."
			}
		},
		submitHandler: function(form) {
		form.submit();
		}
	});
});
</script>
<?php
include_once("footer.php");
?>