<?php
if (!isset($_SESSION)) {
    session_start();
  }
include_once("header.php");
$scriptName = basename(__FILE__);
require_once("conn.php");

$Option	= !empty($_GET["Option"]) ? $_GET["Option"] : "";
$Option	= !empty($_POST["Option"]) ? $_POST["Option"] : $Option;

if($Option == "Show"){
	//echo "_POST<pre>";print_r($_POST);echo "</pre>";exit;
	$scrTime = $_POST['scrTime'];
    $strSQL="SELECT scr.scrid, scr.scrTime, scr.scrTicketPrice, m.mid, m.gids, m.mName, m.mSummary, mr.mrName FROM tbScreenings scr JOIN tbMovies m ON scr.mid = m.mid JOIN tbMovieRooms mr ON scr.mrid = mr.mrid JOIN tbGenres g ON g.gid = m.gids WHERE '".$scrTime." 00:00:00' <= scr.scrTime AND scr.scrTime <= '".$scrTime." 23:59:59' ORDER BY scr.scrTime";
	//echo "strSQL = $strSQL<br />\n";
	$rez = mysqli_query($conn,$strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
	if(mysqli_num_rows($rez)){
		while($row = mysqli_fetch_assoc($rez)){
			$arrGenres = array();
			if(!empty($row["gids"])){
				$strSQL = "SELECT gName FROM tbGenres WHERE gid IN (".$row["gids"].")";
				//echo "strSQL = $strSQL<br />\n";
				$tmpRez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
				while($tmpRow = mysqli_fetch_assoc($tmpRez)){
					$arrGenres[] = $tmpRow["gName"];
				}
			}
			?>
			<div class="row">
				<div class="col-sm-3 noPadding colorBlue mb-2 text-center">
				<h4><?php $row["mName"]?></h4>
			</div>
			<div class="row">
				<div class="col-sm-3 noPadding mb-4">
					<img class="img-fluid" src="img/movie-<?=$row["mid"]?>.jpg"/>
				</div>
				<div class="col-sm-3 colorWhite">
					<h6><?=date("H:i", strtotime($row["scrTime"]))?></h6>
					<h6><?=implode(", ", $arrGenres)?></h6>	
					<h6>Movie room: <?=$row["mrName"]?></h6>
					<h6>Ticket price: <?=$row["scrTicketPrice"]?>$</h6>	
					<form action="reserve.php" method="post">
						<input type="hidden" name="scrid" value="<?=$row["scrid"]?>" />
						<input type="hidden" name="Option" value="Reserve"/>
						<button type="submit" class="btn btnColor btn-sm mb-5">Reserve a ticket</button>
					</form>
				</div>
				<div class="col-sm-6 colorWhite">
					<?php nl2br($row["mSummary"])?>
				</div>
			</div>
			<?php
		}
	}else{
		?>
		<div class="alert alert-danger">
			<strong>Note!</strong>No schedule.
		</div>
		<?php
	}
	exit;
}
$pageTitle = "Cinema | Home";

?>
<?php
$strOUT		= '';
$thisYear	= date("Y");
$thisMonth	= date("m");
$lastDay	= date("t");
$strSQL		= "SELECT mid FROM tbScreenings ";
//echo "strSQL = $strSQL<br />\n";
$rez= mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
if(mysqli_num_rows($rez)){
	$i = 0;
	$strIndicators = '';
	$strItems = '';
	while($row = mysqli_fetch_assoc($rez)){
		$strIndicators .= '
		<li data-target="#movieCarousel" data-slide-to="'.$i.'"'.(empty($i) ? ' class="active"' : '').'></li>';
		$strItems .= '
		<div class="carousel-item'.(empty($i) ? ' active' : '').'"><img src="img/movie-'.$row["mid"].'.jpg" class="w-100 d-block"></div>';
		$i++;
	}
	$strOUT = '
<!--section with carousel-->
<section id="home" class="bgColorWhite">
	<div class="container py-4">
		<div class="row text-center">
			<div class="col-md-9 mx-auto">
				<h1 class="colorBlue mt-5 styleFont"><i class="fas fa-film colorBlack mr-2"></i>Movies this month</h1>	
				<!--carousel-->
				<div id="movieCarousel" class="carousel slide mt-4" data-ride="carousel">
					<ul class="carousel-indicators">
						'.$strIndicators.'
					</ul>
					<!--images in carousel-->
					<div class="carousel-inner">
						'.$strItems.'
					</div>
					<!--end of images in carousel-->
					<a href="#movieCarousel" class="carousel-control-prev" data-slide="prev"><span class="carousel-control-prev-icon"></span></a>
					<a href="#movieCarousel" class="carousel-control-next" data-slide="next"><span class="carousel-control-next-icon"></span></a>
				</div>
				<!--end of carousel-->
			</div>
		</div>
	</div>
</section>
<!--end of section with carrousel-->';
}
echo $strOUT;
?>
<!--section for screenings-->
<section id="screenings" class="bgColorBlack">	
	<div class="container py-5">
		<h1 class="colorBlue text-center py-2 styleFont">Screenings</h1>
		<div class="form-group row">
			<div class="col-xs-3">
				<form id="frmChoose" method="post" action="">
					<input type="hidden" id="scriptName" name="scriptName" value="<?=$scriptName?>" />
					<input type="hidden" id="Option" name="Option" value="Show" />
					<label class="colorWhite ml-2" for="scrTime">Select the day of the screening: </label>
					<select class="form-control mb-3 ml-2" id="scrTime" name="scrTime" required>
					<option value="" selected >Choose ...</option>
					<?php
					$timeNow = date("H:i");
					$arrListed = array();
					$strSQL = "SELECT scrTime FROM tbScreenings WHERE scrActive = 1 AND scrTime > '".$timeNow."'";
					//echo "strSQL = $strSQL<br />\n";
					
					$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
					while($row = mysqli_fetch_assoc($rez)){
						$theDate = date("Y-m-d", strtotime($row["scrTime"]));
						if(!in_array($theDate, $arrListed)){
							?>
							<option value="<?=$theDate?>"><?=date("l, j F", strtotime($theDate))?></option>
							<?php
							$arrListed[] = $theDate;
						}
					}
					?>
					</select>
				</form>
			</div>
		</div>
		<div id="showResult"></div>
	</div>
</section>
<!--end of section for screenings-->
<!--ajax for movie screenings-->
<script type="text/javascript">
$(function(){
	$("#scrTime").unbind().change(function(){
		if($("#scrTime").val() != ""){
			var formData = $("#frmChoose").serialize();
			$.post(
				$("#scriptName").val(),
				formData, 
				function(txt){
					$("#showResult").html(txt);
				}
			);
		}else{
			$("#showResult").html("");
		}
	});
});
</script>
<!--end of ajax for movie screenings-->
<?php include_once("footer.php")?>