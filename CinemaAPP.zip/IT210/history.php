<?php
$scriptName = basename(__FILE__);
require_once("conn.php");

if(empty($_SESSION["uid"])){
	header("location: ./");
	exit;
}

$Option	= !empty($_GET["Option"]) ? $_GET["Option"] : "";
$Option	= !empty($_POST["Option"]) ? $_POST["Option"] : $Option;

$msg = '';
if($Option == "Delete"){
	$strSQL = "DELETE FROM tbOrders WHERE oid = ".(int)$_GET["oid"];
	//echo "strSQL = $strSQL<br />\n";
	mysqli_query($conn,$strSQL) or die("Error: ".mysqli_error($conn));
	$msg = '
	<div class="alert alert-success mt-5">
	  <strong>Success!</strong> Item deleted.
	</div>';
}
$pageTitle ="Cinema | My account";
include_once("header.php");
?>
<!--section history-->
<section class="bgColorWhite">
	<div class="container py-4">
		<div class="row text-center">
			<div class="col-sm-8 mx-auto">
				<h1 class="colorBlue styleFont mt-5 mb-3">My history of watched movies</h1>
				<div class="table-responsive">
					<table class="table table-dark table-hover table-bordered text-center">
						<thead class="thead-dark">
							<tr>
								<th></th>
								<th>Movie name</th>
								<th>Screening time</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$strSQL = "SELECT scr.scrTime, m.mName, m.mid,o.oid FROM tbScreenings scr JOIN tbMovies m ON scr.scrid = m.mid JOIN tbOrders o ON scr.scrid = o.scrid WHERE o.uid = ".$_SESSION["uid"];
						//echo "strSQL = $strSQL<br />\n";
						$rez = mysqli_query($conn, $strSQL) or die($strSQL." ".__FILE__." ".__LINE__." ".mysqli_error($conn));
						$i = 1;
						while($row = mysqli_fetch_assoc($rez)){
							?>
							<tr>
								<td><?=$i?></td>
								<td><?=$row["mName"]?></td>
								<td><?=$row["scrTime"]?></td>
								<td>
									
									<button class="btn btn-danger btn-sm" onclick="if(confirm('Do you really want to delete the selected item?')){location='?Option=Delete&oid=<?=$row["oid"]?>'}"><i class="fas fa-trash-alt "></i>
									</button>
								</td>
							</tr>
							<?php
							$i++;
						}
						?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<?php $msg?>
   </div>
</section>
<!--end of section history-->
<?php
include_once("footer.php");
?>