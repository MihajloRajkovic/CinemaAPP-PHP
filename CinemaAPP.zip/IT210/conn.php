<?php


define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASS','');
define('DB_NAME','cinemaa');

$conn = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASS,DB_NAME) or die("Connection failed.".mysqli_error($conn));

?>