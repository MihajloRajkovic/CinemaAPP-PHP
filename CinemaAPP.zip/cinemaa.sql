-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2022 at 11:59 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cinemaa`
--
CREATE DATABASE IF NOT EXISTS `cinemaa` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cinemaa`;

-- --------------------------------------------------------

--
-- Table structure for table `poruke`
--

CREATE TABLE `poruke` (
  `ime` text NOT NULL,
  `prezime` text NOT NULL,
  `broj` int(11) NOT NULL,
  `poruka` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `poruke`
--

INSERT INTO `poruke` (`ime`, `prezime`, `broj`, `poruka`) VALUES
('Mihajlo', 'Rajkovic', 43, 'akjsgdasdiuajsd');

-- --------------------------------------------------------

--
-- Table structure for table `tbgenres`
--

CREATE TABLE `tbgenres` (
  `gid` int(1) NOT NULL,
  `gActive` tinyint(4) NOT NULL DEFAULT 1,
  `gName` varchar(40) DEFAULT NULL,
  `gUpdated` datetime DEFAULT NULL,
  `gCreated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbgenres`
--

INSERT INTO `tbgenres` (`gid`, `gActive`, `gName`, `gUpdated`, `gCreated`) VALUES
(1, 1, 'animation', '2022-08-30 13:42:58', '2022-08-29 13:42:58'),
(2, 1, 'adventure', '2022-08-30 13:43:13', '2022-08-29 13:43:13'),
(3, 1, 'comedy', '2022-08-30 13:43:38', '2022-08-29 13:43:38'),
(4, 1, 'action', '2022-08-30 13:43:38', '2022-08-29 13:43:38'),
(5, 1, 'crime', '2022-08-30 13:44:14', '2022-08-29 13:44:14'),
(6, 1, 'drama', '2022-08-30 13:44:14', '2022-08-29 13:44:14'),
(7, 1, 'romance', '2022-08-30 13:44:52', '2022-08-29 13:44:52'),
(8, 1, 'fantasy', '2022-08-30 13:44:52', '2022-08-29 13:44:52'),
(9, 1, 'horror', '2022-08-30 13:45:26', '2022-08-29 13:45:26'),
(10, 1, 'war', '2022-08-30 13:45:26', '2022-08-29 13:45:26'),
(11, 1, 'mystery', '2022-08-30 13:46:03', '2022-08-29 13:46:03'),
(12, 1, 'sci-fi', '2022-08-30 13:46:03', '2022-08-29 13:46:03');

-- --------------------------------------------------------

--
-- Table structure for table `tbmovierooms`
--

CREATE TABLE `tbmovierooms` (
  `mrid` int(1) NOT NULL,
  `mrActive` tinyint(4) NOT NULL DEFAULT 1,
  `mrName` varchar(32) DEFAULT NULL,
  `mrCapacity` int(1) DEFAULT NULL,
  `mrUpdated` datetime DEFAULT NULL,
  `mrCreated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbmovierooms`
--

INSERT INTO `tbmovierooms` (`mrid`, `mrActive`, `mrName`, `mrCapacity`, `mrUpdated`, `mrCreated`) VALUES
(1, 1, '3D', 30, '2022-08-30 13:46:45', '2022-08-29 13:46:45'),
(2, 1, '2D', 50, '2022-08-30 13:46:45', '2022-08-29 13:46:45'),
(3, 1, '1A', 60, '2022-08-30 13:47:32', '2022-08-29 13:47:32'),
(4, 1, '2A', 100, '2022-08-30 13:47:32', '2022-08-29 13:47:32'),
(5, 1, '1B', 30, '2022-08-30 13:48:08', '2022-08-29 13:48:08'),
(6, 1, 'A4', 30, NULL, '2022-09-04 21:09:34');

-- --------------------------------------------------------

--
-- Table structure for table `tbmovies`
--

CREATE TABLE `tbmovies` (
  `mid` int(11) NOT NULL,
  `mName` varchar(100) DEFAULT NULL,
  `mActive` tinyint(4) NOT NULL DEFAULT 1,
  `gids` varchar(50) DEFAULT NULL,
  `mLength` int(1) DEFAULT NULL,
  `mSummary` varchar(500) DEFAULT NULL COMMENT 'Plot summary',
  `mUpdated` datetime DEFAULT NULL,
  `mCreated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbmovies`
--

INSERT INTO `tbmovies` (`mid`, `mName`, `mActive`, `gids`, `mLength`, `mSummary`, `mUpdated`, `mCreated`) VALUES
(1, 'Bad boys for life', 1, '3,4,5', 110, 'Marcus and Mike have to confront new issues (career changes and midlife crises), as they join the newly created elite team AMMO of the Miami police department to take down the ruthless Armando Armas, the vicious leader of a Miami drug cartel.', '2022-08-30 13:48:39', '2022-08-29 13:48:39'),
(2, 'Avengers', 1, '2,4,6', 130, 'After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos\' actions and restore balance to the universe.', '2022-08-30 13:48:39', '2022-08-29 13:48:39'),
(3, 'Marriage story', 1, '3,6,7', 110, 'MARRIAGE STORY is Academy Award nominated filmmaker Noah Baumbach\'s incisive and compassionate look at a marriage breaking up and a family staying together. The film stars Scarlett Johansson and Adam Driver. Laura Dern, Alan Alda, and Ray Liotta co-star.', '2022-08-30 13:51:01', '2022-08-29 13:51:01'),
(4, 'IT:Chapter two', 1, '6,8,9', 140, 'Twenty-seven years after their first encounter with the terrifying Pennywise, the Losers Club have grown up and moved away, until a devastating phone call brings them back.', '2022-08-30 13:51:01', '2022-08-29 13:51:01'),
(5, '1917', 1, '10', 150, 'April 6th, 1917. As a regiment assembles to wage war deep in enemy territory, two soldiers are assigned to race against time and deliver a message that will stop 1,600 men from walking straight into a deadly trap.', '2022-08-30 13:52:41', '2022-08-29 13:52:41'),
(6, 'Frozen 2', 1, '1', 95, 'Set three years after the events of the first film \"Frozen , from 2013\" , the story follows Elsa, Anna, Kristoff, Olaf, and Sven, who embark on a journey beyond their kingdom of Arendelle in order to discover the origin of Elsa\'s magical powers and save their kingdom after a mysterious voice calls out to Elsa.', '2022-08-30 13:52:41', '2022-08-29 13:52:41'),
(7, 'The invisible man', 1, '9,11,12', 107, 'The film follows Cecilia, who receives the news of her abusive ex-boyfriend\'s suicide. She begins to re-build her life for the better. However, her sense of reality is put into question when she begins to suspect her deceased lover is not actually dead.', '2022-08-30 13:54:06', '2022-08-29 13:54:06'),
(8, 'Toy story 4', 1, '1,3', 96, 'Woody and the gang go on a road trip with new toy Forky, who\'s convinced he\'s trash and doesn\'t yet understand his role in the world. Along the way, Woody is unexpectedly reunited with independent spirit Bo Peep and finds himself faced with a decision, and a future, he never imagined.', '2022-08-30 13:54:06', '2022-08-29 13:54:06');

-- --------------------------------------------------------

--
-- Table structure for table `tborders`
--

CREATE TABLE `tborders` (
  `oid` int(1) NOT NULL,
  `uid` int(1) NOT NULL,
  `scrid` int(1) NOT NULL,
  `oCreated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tborders`
--

INSERT INTO `tborders` (`oid`, `uid`, `scrid`, `oCreated`) VALUES
(1, 2, 1, NULL),
(2, 5, 4, '2022-08-30 22:32:46'),
(3, 6, 1, '2022-08-31 23:37:02'),
(4, 8, 1, '2022-08-31 23:48:41'),
(5, 8, 4, '2022-08-31 23:48:55'),
(7, 10, 3, '2022-09-02 15:01:11'),
(8, 10, 1, '2022-09-02 15:01:29'),
(9, 11, 1, '2022-09-04 19:48:34'),
(10, 2, 3, '2022-09-04 19:56:13');

-- --------------------------------------------------------

--
-- Table structure for table `tbscreenings`
--

CREATE TABLE `tbscreenings` (
  `scrid` int(1) NOT NULL,
  `mid` int(1) NOT NULL,
  `mrid` int(1) NOT NULL,
  `scrActive` tinyint(1) DEFAULT 1,
  `scrTicketPrice` decimal(7,0) DEFAULT NULL,
  `scrTime` datetime DEFAULT NULL,
  `scrUpdated` datetime DEFAULT NULL,
  `scrCreated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbscreenings`
--

INSERT INTO `tbscreenings` (`scrid`, `mid`, `mrid`, `scrActive`, `scrTicketPrice`, `scrTime`, `scrUpdated`, `scrCreated`) VALUES
(1, 2, 3, 1, '5', '2022-08-30 18:00:00', NULL, NULL),
(2, 3, 1, 1, '6', '2022-08-30 19:50:00', NULL, NULL),
(3, 4, 4, 1, '5', '2022-08-31 14:00:00', NULL, NULL),
(4, 5, 1, 1, '10', '2022-08-31 14:30:00', NULL, NULL),
(5, 1, 5, 1, '5', '2022-09-14 20:55:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbusers`
--

CREATE TABLE `tbusers` (
  `uid` int(1) NOT NULL,
  `uRole` tinyint(1) DEFAULT NULL COMMENT '0-user, 1-admin',
  `uName` varchar(50) DEFAULT NULL,
  `uEmail` varchar(50) DEFAULT NULL,
  `uPass` varchar(50) DEFAULT NULL,
  `uUpdated` date DEFAULT NULL,
  `uCreated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbusers`
--

INSERT INTO `tbusers` (`uid`, `uRole`, `uName`, `uEmail`, `uPass`, `uUpdated`, `uCreated`) VALUES
(1, 1, 'admin', 'admin@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL),
(2, 0, 'dana', 'd@d.com', '5e346440cd0f48e921f482f11ad825a3', NULL, '2022-09-04 20:21:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbgenres`
--
ALTER TABLE `tbgenres`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `tbmovierooms`
--
ALTER TABLE `tbmovierooms`
  ADD PRIMARY KEY (`mrid`);

--
-- Indexes for table `tbmovies`
--
ALTER TABLE `tbmovies`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `tborders`
--
ALTER TABLE `tborders`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `scrid` (`scrid`);

--
-- Indexes for table `tbscreenings`
--
ALTER TABLE `tbscreenings`
  ADD PRIMARY KEY (`scrid`),
  ADD KEY `mid` (`mid`),
  ADD KEY `mrid` (`mrid`);

--
-- Indexes for table `tbusers`
--
ALTER TABLE `tbusers`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbgenres`
--
ALTER TABLE `tbgenres`
  MODIFY `gid` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbmovierooms`
--
ALTER TABLE `tbmovierooms`
  MODIFY `mrid` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbmovies`
--
ALTER TABLE `tbmovies`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tborders`
--
ALTER TABLE `tborders`
  MODIFY `oid` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbscreenings`
--
ALTER TABLE `tbscreenings`
  MODIFY `scrid` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbusers`
--
ALTER TABLE `tbusers`
  MODIFY `uid` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tborders`
--
ALTER TABLE `tborders`
  ADD CONSTRAINT `scrid` FOREIGN KEY (`scrid`) REFERENCES `tbscreenings` (`scrid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `uid` FOREIGN KEY (`uid`) REFERENCES `tbusers` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbscreenings`
--
ALTER TABLE `tbscreenings`
  ADD CONSTRAINT `mid` FOREIGN KEY (`mid`) REFERENCES `tbmovies` (`mid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mrid` FOREIGN KEY (`mrid`) REFERENCES `tbmovierooms` (`mrid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
